/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil -*- */

void Tcl_kadm5_init(Tcl_Interp *interp);
