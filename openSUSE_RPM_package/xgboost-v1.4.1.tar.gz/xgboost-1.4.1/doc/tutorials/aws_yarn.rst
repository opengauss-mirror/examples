###############################
Distributed XGBoost YARN on AWS
###############################
[This page is under construction.]

.. note:: XGBoost with Spark

  If you are preprocessing training data with Spark, consider using :doc:`XGBoost4J-Spark </jvm/xgboost4j_spark_tutorial>`.
