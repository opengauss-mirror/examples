package org.example.entity;

import lombok.Data;

@Data
public class StringEntity {
    String c1;
    String c2;
    String c3;
}
