package org.example.entity;

import lombok.Data;

@Data
public class BinaryEntity {
    byte[] c1;
    byte[] c2;
}
