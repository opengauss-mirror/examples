package org.example.entity;

import lombok.Data;

import java.math.BigInteger;

@Data
public class IntEntity {
    Byte c1;
    Short c2;
    Integer c3;
    BigInteger c4;
    Byte c5;
    Short c6;
    Integer c7;
    BigInteger c8;
}
