package org.example.entity;

import lombok.Data;

@Data
public class BitEntity {
    boolean c1;
    boolean c2;
    boolean c3;
    boolean c4;
}
