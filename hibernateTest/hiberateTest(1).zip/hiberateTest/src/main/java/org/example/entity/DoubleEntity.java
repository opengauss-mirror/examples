package org.example.entity;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class DoubleEntity {
    double c1;
    double c2;
    BigDecimal c3;
    BigDecimal c4;
    BigDecimal c5;
    BigDecimal c6;
}
