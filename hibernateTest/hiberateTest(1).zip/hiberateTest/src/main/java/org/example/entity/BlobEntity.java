package org.example.entity;

import lombok.Data;

@Data
public class BlobEntity {
    Object c1;
    Object c2;
    Object c3;
    Object c4;
}
