"""OpenGauss Django 数据库后端包。"""

__all__ = ["__version__"]
__version__ = "1.0.2"
